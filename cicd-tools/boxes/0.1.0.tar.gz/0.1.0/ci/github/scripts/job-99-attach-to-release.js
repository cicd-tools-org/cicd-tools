// CI only script.

/**
 * @description Uploads files to a GitHub release.
 * (See the {@link https://github.com/actions/github-script|script action} repository for details.)
 *
 * @param {object} args.context - An object containing the context of the workflow run.
 * @param {string} args.files - The newline separated list of files to attach to the release.
 * @param {object} args.core - A reference to the @actions/core package.
 * @param {object} args.github - A pre-authenticated octokit/rest.js client with pagination plugins.
 * @param {string} args.release - The release context.
 *
 */
module.exports = async ({ context, core, files, github, release }) => {
    console.debug(`DEBUG: -- ${__filename} --`)
    files.split('\n').forEach(async (file) => {
        try {
            upload_filename = file.trim()
            const result = await github.rest.repos.uploadReleaseAsset({
                data: upload_filename,
                headers: {
                    'content-type': 'application/octet-stream',
                },
                name: upload_filename,
                owner: context.repo.owner,
                release_id: release.data.id,
                repo: context.repo.repo,
            })
            return result
        } catch (error) {
            core.setFailed(error.message)
        }
    }
}